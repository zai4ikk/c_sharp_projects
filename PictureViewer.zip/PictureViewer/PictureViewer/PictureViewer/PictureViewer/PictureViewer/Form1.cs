﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

//Директива using позволяет использовать типы,
//определенные в пространстве имен, без 
//указания полного пространства имен этого типа.
//В базовой форме //директива using импортирует все
//типы из одного пространства имен

namespace PictureViewer
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        //private: закрытый или приватный компонент класса или структуры. Приватный 
        //компонент доступен только в рамках своего класса или структуры.
        //EventArgs e - это параметр с именем e, который содержит данные о событии, см. 
        //страницу MSDN EventArgs для получения дополнительной информации.

        //Object Sender - это параметр с именем Отправитель, который содержит ссылку на 
        //элемент управления/объект, вызвавший событие.
        {

        }

        private void tableLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void ShowButton_Click(object sender, EventArgs e)
        {
            // Показать диалоговое окно "Открыть файл". Если пользователь нажмет кнопку ОК, загрузите изображение
            //, которое выбрал пользователь.

            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                pictureBox1.Load(openFileDialog1.FileName);
            }
        }

        private void ClearButton_Click(object sender, EventArgs e)
        {
            // Очистить изображение
            pictureBox1.Image = null;
        }

        private void BackgroundButton_Click(object sender, EventArgs e)
        {
            // Показать диалоговое окно "Цвет". Если пользователь нажмет кнопку ОК,
            // измениnt фон элемента управления
            // PictureBox на выбранный пользователем цвет.
            if (colorDialog1.ShowDialog() == DialogResult.OK)
                pictureBox1.BackColor = colorDialog1.Color;
        }

        private void CloseButton_Click(object sender, EventArgs e)
        {
            // Закрыть форму
            this.Close();
        }


        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            //  Если пользователь установит флажок Растягивать,
            //  измените поле изображения
            // Свойство SizeMode для "растягивания". Если пользователь снимает флажок
            //, измените его на "Обычный".
            if (checkBox1.Checked)
                pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            else
                pictureBox1.SizeMode = PictureBoxSizeMode.Normal;
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void закрытьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // Закрыть форму
            this.Close();
        }


        private void показатьРисунокToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // Показать диалоговое окно "Открыть файл". Если пользователь нажмет кнопку ОК, загрузите изображение
            //, которое выбрал пользователь.

            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                pictureBox1.Load(openFileDialog1.FileName);
            }
        }

        private void правкаToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void установитьЦветФонаToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (colorDialog1.ShowDialog() == DialogResult.OK)
                pictureBox1.BackColor = colorDialog1.Color;
        }

        private void растянутьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
        }

        private void отменитьРастяжениеToolStripMenuItem_Click(object sender, EventArgs e)
        {
            pictureBox1.SizeMode = PictureBoxSizeMode.Normal;
        }

        private void очиститьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            pictureBox1.Image = null;
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                pictureBox2.Load(openFileDialog1.FileName);
            }
        }
    }
}
