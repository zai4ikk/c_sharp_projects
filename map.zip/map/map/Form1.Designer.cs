﻿namespace map
{
    partial class map
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.button1 = new System.Windows.Forms.Button();
            this.DrinksText = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.ToiletsText = new System.Windows.Forms.Label();
            this.EnergyBarsText = new System.Windows.Forms.Label();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.Checkpoint1 = new System.Windows.Forms.Panel();
            this.LandmarkName = new System.Windows.Forms.Label();
            this.Landmark = new System.Windows.Forms.Label();
            this.ServicesProvided = new System.Windows.Forms.Label();
            this.Checkpoint = new System.Windows.Forms.Label();
            this.MedicalPaint = new System.Windows.Forms.PictureBox();
            this.InfaPaint = new System.Windows.Forms.PictureBox();
            this.InfaText = new System.Windows.Forms.Label();
            this.MedicalText = new System.Windows.Forms.Label();
            this.EnergyBarsPaint = new System.Windows.Forms.PictureBox();
            this.DrinksPaint = new System.Windows.Forms.PictureBox();
            this.ToiletsPaint = new System.Windows.Forms.PictureBox();
            this.pictureBox16 = new System.Windows.Forms.PictureBox();
            this.pictureBox17 = new System.Windows.Forms.PictureBox();
            this.pictureBox12 = new System.Windows.Forms.PictureBox();
            this.point1 = new System.Windows.Forms.PictureBox();
            this.point5 = new System.Windows.Forms.PictureBox();
            this.point4 = new System.Windows.Forms.PictureBox();
            this.start1 = new System.Windows.Forms.PictureBox();
            this.point3 = new System.Windows.Forms.PictureBox();
            this.point2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.start2 = new System.Windows.Forms.PictureBox();
            this.panel1.SuspendLayout();
            this.Checkpoint1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.MedicalPaint)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.InfaPaint)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.EnergyBarsPaint)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DrinksPaint)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ToiletsPaint)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox16)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox17)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.point1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.point5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.point4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.start1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.point3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.point2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.start2)).BeginInit();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.ForeColor = System.Drawing.SystemColors.ControlText;
            this.button1.Location = new System.Drawing.Point(17, 9);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(65, 23);
            this.button1.TabIndex = 0;
            this.button1.Text = "назад";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // DrinksText
            // 
            this.DrinksText.AutoSize = true;
            this.DrinksText.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.DrinksText.Location = new System.Drawing.Point(62, 170);
            this.DrinksText.Name = "DrinksText";
            this.DrinksText.Size = new System.Drawing.Size(125, 24);
            this.DrinksText.TabIndex = 10;
            this.DrinksText.Text = "Стенд питья";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.button1);
            this.panel1.ForeColor = System.Drawing.SystemColors.ButtonShadow;
            this.panel1.Location = new System.Drawing.Point(2, 1);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(823, 48);
            this.panel1.TabIndex = 11;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label3.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label3.Location = new System.Drawing.Point(112, 4);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(543, 31);
            this.label3.TabIndex = 13;
            this.label3.Text = "Интерактивная карта Marathon Skills 2016";
            // 
            // ToiletsText
            // 
            this.ToiletsText.AutoSize = true;
            this.ToiletsText.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.ToiletsText.Location = new System.Drawing.Point(62, 262);
            this.ToiletsText.Name = "ToiletsText";
            this.ToiletsText.Size = new System.Drawing.Size(72, 24);
            this.ToiletsText.TabIndex = 13;
            this.ToiletsText.Text = "Туалет";
            // 
            // EnergyBarsText
            // 
            this.EnergyBarsText.AutoSize = true;
            this.EnergyBarsText.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.EnergyBarsText.Location = new System.Drawing.Point(62, 216);
            this.EnergyBarsText.Name = "EnergyBarsText";
            this.EnergyBarsText.Size = new System.Drawing.Size(258, 24);
            this.EnergyBarsText.TabIndex = 14;
            this.EnergyBarsText.Text = "Энергетические батончики";
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Location = new System.Drawing.Point(2, 479);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(80, 17);
            this.checkBox1.TabIndex = 17;
            this.checkBox1.Text = "checkBox1";
            this.checkBox1.UseVisualStyleBackColor = true;
            this.checkBox1.CheckedChanged += new System.EventHandler(this.checkBox1_CheckedChanged);
            // 
            // Checkpoint1
            // 
            this.Checkpoint1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.Checkpoint1.Controls.Add(this.LandmarkName);
            this.Checkpoint1.Controls.Add(this.Landmark);
            this.Checkpoint1.Controls.Add(this.ServicesProvided);
            this.Checkpoint1.Controls.Add(this.Checkpoint);
            this.Checkpoint1.Controls.Add(this.MedicalPaint);
            this.Checkpoint1.Controls.Add(this.InfaPaint);
            this.Checkpoint1.Controls.Add(this.InfaText);
            this.Checkpoint1.Controls.Add(this.MedicalText);
            this.Checkpoint1.Controls.Add(this.EnergyBarsPaint);
            this.Checkpoint1.Controls.Add(this.DrinksPaint);
            this.Checkpoint1.Controls.Add(this.EnergyBarsText);
            this.Checkpoint1.Controls.Add(this.ToiletsPaint);
            this.Checkpoint1.Controls.Add(this.ToiletsText);
            this.Checkpoint1.Controls.Add(this.DrinksText);
            this.Checkpoint1.Location = new System.Drawing.Point(448, 69);
            this.Checkpoint1.Name = "Checkpoint1";
            this.Checkpoint1.Size = new System.Drawing.Size(413, 388);
            this.Checkpoint1.TabIndex = 18;
            this.Checkpoint1.Paint += new System.Windows.Forms.PaintEventHandler(this.Checkpoint1_Paint);
            // 
            // LandmarkName
            // 
            this.LandmarkName.AutoSize = true;
            this.LandmarkName.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.LandmarkName.Location = new System.Drawing.Point(36, 63);
            this.LandmarkName.Name = "LandmarkName";
            this.LandmarkName.Size = new System.Drawing.Size(162, 24);
            this.LandmarkName.TabIndex = 20;
            this.LandmarkName.Text = "Название пункта";
            // 
            // Landmark
            // 
            this.Landmark.AutoSize = true;
            this.Landmark.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Landmark.Location = new System.Drawing.Point(12, 26);
            this.Landmark.Name = "Landmark";
            this.Landmark.Size = new System.Drawing.Size(67, 24);
            this.Landmark.TabIndex = 19;
            this.Landmark.Text = "Пункт:";
            // 
            // ServicesProvided
            // 
            this.ServicesProvided.AutoSize = true;
            this.ServicesProvided.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.ServicesProvided.Location = new System.Drawing.Point(18, 110);
            this.ServicesProvided.Name = "ServicesProvided";
            this.ServicesProvided.Size = new System.Drawing.Size(144, 24);
            this.ServicesProvided.TabIndex = 18;
            this.ServicesProvided.Text = "Обслуживание";
            // 
            // Checkpoint
            // 
            this.Checkpoint.AutoSize = true;
            this.Checkpoint.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Checkpoint.Location = new System.Drawing.Point(165, 10);
            this.Checkpoint.Name = "Checkpoint";
            this.Checkpoint.Size = new System.Drawing.Size(75, 24);
            this.Checkpoint.TabIndex = 17;
            this.Checkpoint.Text = "Пункты";
            // 
            // MedicalPaint
            // 
            this.MedicalPaint.Image = global::map.Properties.Resources.map_icon_medical;
            this.MedicalPaint.Location = new System.Drawing.Point(16, 345);
            this.MedicalPaint.Name = "MedicalPaint";
            this.MedicalPaint.Size = new System.Drawing.Size(40, 40);
            this.MedicalPaint.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.MedicalPaint.TabIndex = 6;
            this.MedicalPaint.TabStop = false;
            // 
            // InfaPaint
            // 
            this.InfaPaint.Image = global::map.Properties.Resources.map_icon_information;
            this.InfaPaint.Location = new System.Drawing.Point(16, 295);
            this.InfaPaint.Name = "InfaPaint";
            this.InfaPaint.Size = new System.Drawing.Size(40, 40);
            this.InfaPaint.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.InfaPaint.TabIndex = 2;
            this.InfaPaint.TabStop = false;
            // 
            // InfaText
            // 
            this.InfaText.AutoSize = true;
            this.InfaText.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.InfaText.Location = new System.Drawing.Point(62, 307);
            this.InfaText.Name = "InfaText";
            this.InfaText.Size = new System.Drawing.Size(186, 24);
            this.InfaText.TabIndex = 16;
            this.InfaText.Text = "Стенд информации";
            this.InfaText.Click += new System.EventHandler(this.InfaText_Click);
            // 
            // MedicalText
            // 
            this.MedicalText.AutoSize = true;
            this.MedicalText.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.MedicalText.Location = new System.Drawing.Point(62, 354);
            this.MedicalText.Name = "MedicalText";
            this.MedicalText.Size = new System.Drawing.Size(189, 24);
            this.MedicalText.TabIndex = 15;
            this.MedicalText.Text = "Медицинский пункт";
            this.MedicalText.Click += new System.EventHandler(this.label2_Click);
            // 
            // EnergyBarsPaint
            // 
            this.EnergyBarsPaint.Image = global::map.Properties.Resources.map_icon_energy_bars;
            this.EnergyBarsPaint.Location = new System.Drawing.Point(16, 200);
            this.EnergyBarsPaint.Name = "EnergyBarsPaint";
            this.EnergyBarsPaint.Size = new System.Drawing.Size(40, 40);
            this.EnergyBarsPaint.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.EnergyBarsPaint.TabIndex = 3;
            this.EnergyBarsPaint.TabStop = false;
            // 
            // DrinksPaint
            // 
            this.DrinksPaint.Image = global::map.Properties.Resources.map_icon_drinks;
            this.DrinksPaint.Location = new System.Drawing.Point(16, 154);
            this.DrinksPaint.Name = "DrinksPaint";
            this.DrinksPaint.Size = new System.Drawing.Size(40, 40);
            this.DrinksPaint.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.DrinksPaint.TabIndex = 4;
            this.DrinksPaint.TabStop = false;
            // 
            // ToiletsPaint
            // 
            this.ToiletsPaint.Image = global::map.Properties.Resources.map_icon_toilets;
            this.ToiletsPaint.Location = new System.Drawing.Point(16, 246);
            this.ToiletsPaint.Name = "ToiletsPaint";
            this.ToiletsPaint.Size = new System.Drawing.Size(40, 40);
            this.ToiletsPaint.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.ToiletsPaint.TabIndex = 9;
            this.ToiletsPaint.TabStop = false;
            // 
            // pictureBox16
            // 
            this.pictureBox16.Image = global::map.Properties.Resources.Рисунок8;
            this.pictureBox16.Location = new System.Drawing.Point(21, 163);
            this.pictureBox16.Name = "pictureBox16";
            this.pictureBox16.Size = new System.Drawing.Size(40, 40);
            this.pictureBox16.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox16.TabIndex = 23;
            this.pictureBox16.TabStop = false;
            this.pictureBox16.Click += new System.EventHandler(this.pictureBox16_Click);
            // 
            // pictureBox17
            // 
            this.pictureBox17.Image = global::map.Properties.Resources.Рисунок6;
            this.pictureBox17.Location = new System.Drawing.Point(90, 380);
            this.pictureBox17.Name = "pictureBox17";
            this.pictureBox17.Size = new System.Drawing.Size(40, 40);
            this.pictureBox17.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox17.TabIndex = 24;
            this.pictureBox17.TabStop = false;
            this.pictureBox17.Click += new System.EventHandler(this.pictureBox17_Click);
            // 
            // pictureBox12
            // 
            this.pictureBox12.Image = global::map.Properties.Resources.Рисунок7;
            this.pictureBox12.Location = new System.Drawing.Point(59, 299);
            this.pictureBox12.Name = "pictureBox12";
            this.pictureBox12.Size = new System.Drawing.Size(40, 40);
            this.pictureBox12.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox12.TabIndex = 20;
            this.pictureBox12.TabStop = false;
            this.pictureBox12.Click += new System.EventHandler(this.pictureBox12_Click);
            // 
            // point1
            // 
            this.point1.Image = global::map.Properties.Resources.Рисунок1;
            this.point1.Location = new System.Drawing.Point(255, 79);
            this.point1.Name = "point1";
            this.point1.Size = new System.Drawing.Size(40, 40);
            this.point1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.point1.TabIndex = 21;
            this.point1.TabStop = false;
            this.point1.Click += new System.EventHandler(this.pictureBox13_Click);
            // 
            // point5
            // 
            this.point5.Image = global::map.Properties.Resources.Рисунок5;
            this.point5.Location = new System.Drawing.Point(219, 417);
            this.point5.Name = "point5";
            this.point5.Size = new System.Drawing.Size(40, 40);
            this.point5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.point5.TabIndex = 22;
            this.point5.TabStop = false;
            this.point5.Click += new System.EventHandler(this.point5_Click);
            // 
            // point4
            // 
            this.point4.Image = global::map.Properties.Resources.Рисунок4;
            this.point4.Location = new System.Drawing.Point(377, 360);
            this.point4.Name = "point4";
            this.point4.Size = new System.Drawing.Size(40, 40);
            this.point4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.point4.TabIndex = 21;
            this.point4.TabStop = false;
            this.point4.Click += new System.EventHandler(this.point4_Click);
            // 
            // start1
            // 
            this.start1.Image = global::map.Properties.Resources.map_icon_start;
            this.start1.Location = new System.Drawing.Point(157, 79);
            this.start1.Name = "start1";
            this.start1.Size = new System.Drawing.Size(40, 40);
            this.start1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.start1.TabIndex = 8;
            this.start1.TabStop = false;
            this.start1.Click += new System.EventHandler(this.start1_Click);
            // 
            // point3
            // 
            this.point3.Image = global::map.Properties.Resources.Рисунок2;
            this.point3.Location = new System.Drawing.Point(275, 274);
            this.point3.Name = "point3";
            this.point3.Size = new System.Drawing.Size(40, 40);
            this.point3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.point3.TabIndex = 19;
            this.point3.TabStop = false;
            this.point3.Click += new System.EventHandler(this.point3_Click);
            // 
            // point2
            // 
            this.point2.Image = global::map.Properties.Resources.Рисунок3;
            this.point2.Location = new System.Drawing.Point(284, 186);
            this.point2.Name = "point2";
            this.point2.Size = new System.Drawing.Size(40, 40);
            this.point2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.point2.TabIndex = 18;
            this.point2.TabStop = false;
            this.point2.Click += new System.EventHandler(this.point2_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::map.Properties.Resources.Рисунок10;
            this.pictureBox1.Location = new System.Drawing.Point(12, 69);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(405, 388);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBox5
            // 
            this.pictureBox5.Image = global::map.Properties.Resources.map_icon_start;
            this.pictureBox5.Location = new System.Drawing.Point(21, 232);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(40, 40);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox5.TabIndex = 5;
            this.pictureBox5.TabStop = false;
            this.pictureBox5.Click += new System.EventHandler(this.pictureBox5_Click);
            // 
            // start2
            // 
            this.start2.Image = global::map.Properties.Resources.map_icon_start;
            this.start2.Location = new System.Drawing.Point(173, 400);
            this.start2.Name = "start2";
            this.start2.Size = new System.Drawing.Size(40, 40);
            this.start2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.start2.TabIndex = 7;
            this.start2.TabStop = false;
            this.start2.Click += new System.EventHandler(this.pictureBox7_Click);
            // 
            // map
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(890, 499);
            this.Controls.Add(this.pictureBox16);
            this.Controls.Add(this.pictureBox17);
            this.Controls.Add(this.pictureBox12);
            this.Controls.Add(this.point1);
            this.Controls.Add(this.Checkpoint1);
            this.Controls.Add(this.point5);
            this.Controls.Add(this.checkBox1);
            this.Controls.Add(this.point4);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.start1);
            this.Controls.Add(this.point3);
            this.Controls.Add(this.start2);
            this.Controls.Add(this.point2);
            this.Controls.Add(this.pictureBox5);
            this.Controls.Add(this.pictureBox1);
            this.Name = "map";
            this.Text = "map";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.Checkpoint1.ResumeLayout(false);
            this.Checkpoint1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.MedicalPaint)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.InfaPaint)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.EnergyBarsPaint)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DrinksPaint)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ToiletsPaint)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox16)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox17)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.point1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.point5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.point4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.start1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.point3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.point2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.start2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.PictureBox EnergyBarsPaint;
        private System.Windows.Forms.PictureBox DrinksPaint;
        private System.Windows.Forms.PictureBox start1;
        private System.Windows.Forms.PictureBox ToiletsPaint;
        private System.Windows.Forms.Label DrinksText;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label ToiletsText;
        private System.Windows.Forms.Label EnergyBarsText;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.Panel Checkpoint1;
        private System.Windows.Forms.PictureBox point1;
        private System.Windows.Forms.PictureBox pictureBox12;
        private System.Windows.Forms.PictureBox point3;
        private System.Windows.Forms.PictureBox point2;
        private System.Windows.Forms.Label Checkpoint;
        private System.Windows.Forms.PictureBox MedicalPaint;
        private System.Windows.Forms.PictureBox InfaPaint;
        private System.Windows.Forms.Label InfaText;
        private System.Windows.Forms.Label MedicalText;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox17;
        private System.Windows.Forms.PictureBox pictureBox16;
        private System.Windows.Forms.PictureBox point5;
        private System.Windows.Forms.PictureBox point4;
        private System.Windows.Forms.Label Landmark;
        private System.Windows.Forms.Label ServicesProvided;
        private System.Windows.Forms.Label LandmarkName;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.PictureBox start2;
    }
}

