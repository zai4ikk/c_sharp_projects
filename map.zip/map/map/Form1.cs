﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace map
{
    public partial class map : Form
    {
        public map()
        {
            InitializeComponent();
        }


        private void pictureBox7_Click(object sender, EventArgs e)
        {
            Checkpoint.Text = "Марафон продолжается";
            LandmarkName.Text = "Марафон по ВДНХ";
            DrinksPaint.Visible = false; DrinksText.Visible = false;
            EnergyBarsPaint.Visible = false; EnergyBarsText.Visible = false;
            ToiletsPaint.Visible = false; ToiletsText.Visible = false;
            InfaPaint.Visible = false; InfaText.Visible = false;
            MedicalPaint.Visible = false; MedicalText.Visible = false;
        }

        private void pictureBox13_Click(object sender, EventArgs e)
        {
            Checkpoint.Text = "Пункт 1";
            LandmarkName.Text = "Красная площадь";
            Landmark.Visible = false; ServicesProvided.Visible = false;
            DrinksPaint.Visible = true; DrinksText.Visible = true;
            EnergyBarsPaint.Visible = true; EnergyBarsText.Visible = true;
            ToiletsPaint.Visible = false; ToiletsText.Visible = false;
            InfaPaint.Visible = false; InfaText.Visible = false;
            MedicalPaint.Visible = false; MedicalText.Visible = false;
        }

        private void Checkpoint1_Paint(object sender, PaintEventArgs e)
        {
           
        }

        private void start1_Click(object sender, EventArgs e)
        {
            Checkpoint.Text = "Начало Марафона";
            LandmarkName.Text = "Марафон по Москве";
            Landmark.Visible = false; ServicesProvided.Visible = false;
            DrinksPaint.Visible = false; DrinksText.Visible = false;
            EnergyBarsPaint.Visible = false; EnergyBarsText.Visible = false;
            ToiletsPaint.Visible = false; ToiletsText.Visible = false;
            InfaPaint.Visible = false; InfaText.Visible = false;
            MedicalPaint.Visible = false; MedicalText.Visible = false;
        }

        private void point2_Click(object sender, EventArgs e)
        {
            Checkpoint.Text = "Пункт 2";
            LandmarkName.Text = "Храм Василия Блаженного";
            DrinksPaint.Visible = true; DrinksText.Visible = true;
            ToiletsPaint.Visible = true; ToiletsText.Visible = true;
            EnergyBarsPaint.Visible = true; EnergyBarsText.Visible = true;
            InfaPaint.Visible = true; InfaText.Visible = true;
            MedicalPaint.Visible = true; MedicalText.Visible = true;
        }

        private void point3_Click(object sender, EventArgs e)
        {
            Checkpoint.Text = "Пункт 3";
            LandmarkName.Text = "Лобное место";
            DrinksPaint.Visible = true; DrinksText.Visible = true;
            ToiletsPaint.Visible = true; ToiletsText.Visible = true;
            EnergyBarsPaint.Visible = true; EnergyBarsText.Visible = true;
            InfaPaint.Visible = false; InfaText.Visible = false;
            MedicalPaint.Visible = false; MedicalText.Visible = false;
        }

        private void point4_Click(object sender, EventArgs e)
        {
            Checkpoint.Text = "Пункт 4";
            LandmarkName.Text = "Мавзолей Ленина";
            DrinksPaint.Visible = true; DrinksText.Visible = true;
            ToiletsPaint.Visible = true; ToiletsText.Visible = true;
            EnergyBarsPaint.Visible = true; EnergyBarsText.Visible = true;
            InfaPaint.Visible = false; InfaText.Visible = false;
            MedicalPaint.Visible = true; MedicalText.Visible = true;

            MedicalPaint.Location= new Point(16, 292);
        }

        private void point5_Click(object sender, EventArgs e)
        {
            Checkpoint.Text = "Пункт 5";
            LandmarkName.Text = "Универмаг ГУМ";
            DrinksPaint.Visible = true; DrinksText.Visible = true;
            ToiletsPaint.Visible = true; ToiletsText.Visible = true;
            EnergyBarsPaint.Visible = true; EnergyBarsText.Visible = true;
            InfaPaint.Visible = true; InfaText.Visible = true;
            MedicalPaint.Visible = false; MedicalText.Visible = false;
        }

        private void pictureBox17_Click(object sender, EventArgs e)
        {
            Checkpoint.Text = "Пункт 6";
            LandmarkName.Text = "Музей космонавтики";
            DrinksPaint.Visible = true; DrinksText.Visible = true;
            ToiletsPaint.Visible = true; ToiletsText.Visible = true;
            EnergyBarsPaint.Visible = true; EnergyBarsText.Visible = true;
            InfaPaint.Visible = false; InfaText.Visible = false;
            MedicalPaint.Visible = false; MedicalText.Visible = false;
        }

        private void pictureBox12_Click(object sender, EventArgs e)
        {
            Checkpoint.Text = "Пункт 7";
            LandmarkName.Text = "Фонтан Дружба народов";
            DrinksPaint.Visible = true; DrinksText.Visible = true;
            ToiletsPaint.Visible = true; ToiletsText.Visible = true;
            EnergyBarsPaint.Visible = true; EnergyBarsText.Visible = true;
            InfaPaint.Visible = true; InfaText.Visible = true;
            MedicalPaint.Visible = true; MedicalText.Visible = true;
        }

        private void pictureBox5_Click(object sender, EventArgs e)
        {
            Checkpoint.Text = "Марафон заканчивается";
            LandmarkName.Text = "Воробьевы горы";
            Landmark.Visible = false; ServicesProvided.Visible = false;
            DrinksPaint.Visible = false; DrinksText.Visible = false;
            EnergyBarsPaint.Visible = false; EnergyBarsText.Visible = false;
            ToiletsPaint.Visible = false; ToiletsText.Visible = false;
            InfaPaint.Visible = false; InfaText.Visible = false;
            MedicalPaint.Visible = false; MedicalText.Visible = false;

        }

        private void pictureBox16_Click(object sender, EventArgs e)
        {
            Checkpoint.Text = "Пункт 8";
            LandmarkName.Text = "Мост Лужники";
            DrinksPaint.Visible = true; DrinksText.Visible = true;
            ToiletsPaint.Visible = true; ToiletsText.Visible = true;
            EnergyBarsPaint.Visible = true; EnergyBarsText.Visible = true;
            InfaPaint.Visible = true; InfaText.Visible = true;
            MedicalPaint.Visible = true; MedicalText.Visible = true;
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void InfaText_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
      
        }
    }
}