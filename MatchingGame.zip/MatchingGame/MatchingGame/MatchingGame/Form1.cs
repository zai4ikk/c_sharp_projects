﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MatchingGame
{
    public partial class Form1 : Form
    {
        // // первый щелчок указывает на первый элемент управления Label
        //, на который нажимает игрок, но он будет равен null 
        // если игрок еще не нажал на ярлык
        Label firstClicked = null;

        // // второй щелчок указывает на второй элемент управления меткой
        //, на который нажимает игрок
        Label secondClicked = null;
        // Используйте  случайный объект, чтобы выбрать значки для квадратов
        Random random = new Random();

        // Каждая из этих букв представляет собой значок
        // в шрифте Webdings,
        // и каждый значок появляется дважды в этом списке
        List<string> icons = new List<string>()
    {
        "!", "!", "N", "N", ",", ",", "k", "k",
        "b", "b", "v", "v", "w", "w", "z", "z"
    };
        /// <summary>
        /// Assign each icon from the list of icons to a random square
        /// </summary>
        private void AssignIconsToSquares()
        {
            // Панель TableLayoutPanel имеет 16 меток,
            // а список значков содержит 16 значков,
            // поэтому значок выбирается случайным образом из списка
            // и добавляется к каждой метке
            foreach (Control control in tableLayoutPanel1.Controls)
            {
                Label iconLabel = control as Label;
                if (iconLabel != null)
                {
                    int randomNumber = random.Next(icons.Count);
                    iconLabel.Text = icons[randomNumber];
                    icons.RemoveAt(randomNumber);
                }
            }
        }
        public Form1()
        {
            InitializeComponent();

            AssignIconsToSquares();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {
            // Таймер включается только после того, как игроку были показаны два несоответствующих
            // значка,
            // поэтому игнорируйте любые щелчки, если таймер запущен
            if (timer1.Enabled == true)
                return;

            Label clickedLabel = sender as Label;

            if (clickedLabel != null)
            {
                // Если нажатая метка черная, игрок нажал
                // значок, который уже был показан --
                // игнорировать щелчок
                if (clickedLabel.ForeColor == Color.Black)
                    return;

                // Если значение firstClicked равно нулю, это первый значок
                // в паре, на который нажал игрок,
                // // поэтому установите значение first Clicked для метки, на которую нажал игрок
                //, измените ее цвет на черный и верните
                if (firstClicked == null)
                {
                    firstClicked = clickedLabel;
                    firstClicked.ForeColor = Color.Black;
                    return;
                }

                // Если игрок заходит так далеко, таймер не
                // // запущен, и первый щелчок не равен нулю,
                // так что это должен быть второй значок, на который нажал игрок.
                // Установите его цвет на черный
                secondClicked = clickedLabel;
                secondClicked.ForeColor = Color.Black;

                // Проверьте, выиграл ли игрок
                CheckForWinner();

                // Если игрок нажал на два одинаковых значка, оставьте их
                // // черными и сбросьте первый щелчок и второй щелчок
                //, чтобы игрок мог нажать на другой значок
                if (firstClicked.Text == secondClicked.Text)
                {
                    firstClicked = null;
                    secondClicked = null;
                    return;
                }

                // Если игрок зашел так далеко, игрок
                // нажал на две разные иконки, поэтому запустите
                // таймер (который подождет три четверти
                // секунды, а затем скроет значки)
                timer1.Start();
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            // Остановить таймер
            timer1.Stop();

            // Скрыть оба значка
            firstClicked.ForeColor = firstClicked.BackColor;
            secondClicked.ForeColor = secondClicked.BackColor;

            // // Сбросить первый щелчок и второй щелчок
            // так что в следующий раз, когда метка будет
            // щелкнул, программа знает, что это первый щелчок
            firstClicked = null;
            secondClicked = null;
        }

        private void CheckForWinner()
        {
            // Просмотрите все метки в TableLayoutPanel,
            // проверяя каждую из них, чтобы увидеть, соответствует ли ее значок
            foreach (Control control in tableLayoutPanel1.Controls)
            {
                Label iconLabel = control as Label;

                if (iconLabel != null)
                {
                    if (iconLabel.ForeColor == iconLabel.BackColor)
                        return;
                }
            }

            // Если цикл не вернулся, он не нашел
            // любые непревзойденные иконки
            // Это означает, что пользователь выиграл.
            // Покажите сообщение и закройте форму
            MessageBox.Show("Вы смогли найти все пары!", "Поздравляю");
            Close();
        }

        private void перезапускToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Restart();
        }
    }
}
