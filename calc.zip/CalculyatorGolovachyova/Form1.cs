﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CalculyatorGolovachyova
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            double rost = Convert.ToDouble(textBox1.Text);
            double ves = Convert.ToDouble(textBox2.Text);
            int BMI = Convert.ToInt32(ves / (rost * rost));
            label19.Text = BMI.ToString();

            if (BMI < 10)
            { trackBar1.Value = 10; label19.Text = "Недостаточный вес";}

            if (BMI < 18.5 && BMI >= 10)
            { trackBar1.Value = Convert.ToInt32(BMI);  label19.Text = "Недостаточный вес"; }

            if (BMI >= 18.5 && BMI <= 24.9)
            { trackBar1.Value = Convert.ToInt32(BMI); label19.Text = "Здоровый вес"; }

            if (BMI <= 30 && BMI > 24.9)
            { trackBar1.Value = Convert.ToInt32(BMI); label19.Text = "Избыточный вес"; }

            if (BMI > 30 && BMI < 35)
            { trackBar1.Value = Convert.ToInt32(BMI); label19.Text = "Ожирение"; }

            if (BMI > 35) { trackBar1.Value = 35; label19.Text = "Ожирение"; }
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            pictureBox3.Image = pictureBox1.Image;
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            pictureBox3.Image = pictureBox2.Image;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Application.Restart();
        }
    }
    }


